require "test_helper"

class TombstoneTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
