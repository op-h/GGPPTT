module ActiveStorage
  module Postgresql
  end
end
