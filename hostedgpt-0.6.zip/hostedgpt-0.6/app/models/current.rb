class Current < ActiveSupport::CurrentAttributes
  attribute :person
  attribute :user
end
