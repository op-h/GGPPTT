class Tombstone < ApplicationRecord
  include Personable
end
