class ApplicationController < ActionController::Base
  include Authenticate
end
