module AssistantsHelper
end
